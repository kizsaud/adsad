package com.example.rupizza;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    ImageView imageView;
    TextView topping;
    View view;
    ToppingsRecyclerInterface toppingsRecyclerInterface;

    public MyViewHolder(@NonNull View itemView, ToppingsRecyclerInterface toppingsRecyclerInterface) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageview);
        topping = itemView.findViewById(R.id.toppingChoice);
        view = itemView;
        this.toppingsRecyclerInterface = toppingsRecyclerInterface;

        itemView.setOnClickListener(this);
    }

    public void bind(final Item item){
        imageView.setVisibility(item.isChecked() ? View.VISIBLE : View.GONE);
        topping.setText(item.getTopping());

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                item.setChecked(!item.isChecked());
                imageView.setVisibility(item.isChecked() ? View.VISIBLE : View.GONE);
            }
        });
    }

    @Override
    public void onClick(View view) {
        toppingsRecyclerInterface.onItemCLick(getAdapterPosition());
    }
}
