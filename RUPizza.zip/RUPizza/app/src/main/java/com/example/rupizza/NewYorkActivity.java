package com.example.rupizza;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class NewYorkActivity extends AppCompatActivity {
    ListView listView;

    ListView listView2;

    TextView priceText;

    TextView crustText;

    TextView selectedItems;

    private Button toppingsButton;

    private Button orderButton;

    private ArrayList<Topping> selectedToppings2=new ArrayList<>();

    String size;

    String type;

    double price;

    String[] toppingChoices;

    int numToppings;

    static double TOPPING_PRICE = 1.59;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_york);

        price = 0.00;
        size = "";
        type = "crust";
        numToppings = 0;
        Bundle extras = getIntent().getExtras();
        if(extras != null){
            String size2 = extras.getString("size");
            double price2 = extras.getDouble("price", 0.00);
            String type2 = extras.getString("type");
            toppingChoices = extras.getStringArray("toppingSelection");
            price = price2;
            size = size2;
            type = "Build Your Own";
        }


        priceText = (TextView)findViewById(R.id.priceField);

        crustText = (TextView)findViewById(R.id.crustText);

        selectedItems = (TextView)findViewById(R.id.selectedFromMenu);


        if(toppingChoices != null){
            numToppings = toppingChoices.length;
            price += (TOPPING_PRICE*numToppings);
            Toast.makeText(NewYorkActivity.this,
                    numToppings + "",
                    Toast.LENGTH_SHORT).show();
        }

        priceText.setText(String.format("%.2f", price));

        crustText.setText(setCrust());

        String display = "";

        if(toppingChoices != null){
            for(int i = 0; i < toppingChoices.length; i++){
                display += toppingChoices[i] + " ";
            }
        }

        selectedItems.setText(display);

        listView = (ListView)findViewById(R.id.listview);

        orderButton = (Button)findViewById(R.id.orderButton);

        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Small");
        arrayList.add("Medium");
        arrayList.add("Large");

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);

        listView.setAdapter(arrayAdapter);

        listView2 = (ListView)findViewById(R.id.listview2);

        ArrayList<String> arrayList2 = new ArrayList<>();
        arrayList2.add("Build Your Own");
        arrayList2.add("BBQ Chicken");
        arrayList2.add("Deluxe");
        arrayList2.add("Meatzza");

        ArrayAdapter arrayAdapter2 = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList2);

        listView2.setAdapter(arrayAdapter2);

        toppingsButton = (Button) findViewById(R.id.toppingsButton);


        if(size == "" && type == "crust"){
            toppingsButton.setEnabled(false);
        }
        else{
            toppingsButton.setEnabled(true);
        }
        toppingsButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openToppingsNY();
            }
        });

        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(size != null && type != null){
                    createPizza();
                    openMain();
                }
                else{
                    if(size == ""){
                        Toast.makeText(NewYorkActivity.this, "Must pick size.",
                                Toast.LENGTH_SHORT).show();
                    }
                    if(type == ""){
                        Toast.makeText(NewYorkActivity.this, "Must pick Type.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                size = arrayAdapter.getItem(position).toString();
                Toast.makeText(NewYorkActivity.this,
                        "Size is: " + size, Toast.LENGTH_SHORT).show();
                if(size != "" && type == "Build Your Own"){
                    toppingsButton.setEnabled(true);
                }
                getPrice();
            }
        });

        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                type = arrayAdapter2.getItem(position).toString();
                Toast.makeText(NewYorkActivity.this,
                        "Type is: " + type, Toast.LENGTH_SHORT).show();
                if(size != "" && type == "Build Your Own"){
                    toppingsButton.setEnabled(true);
                }
                else{
                    toppingsButton.setEnabled(false);
                }
                getPrice();
                crustText.setText(setCrust());
            }
        });



    }
    public String setCrust(){
        String newCrust = "Crust";
        if(type == "BBQ Chicken"){
            newCrust = "Pan";
        }
        else if(type == "Build Your Own"){
            newCrust = "Pan";
        }
        else if(type == "Meatzza"){
            newCrust = "Stuffed";
        }
        else if(type == "Deluxe"){
            newCrust = "Deep Dish";
        }
        else{
            newCrust = "Crust";
        }
        return newCrust;
    }


    public void openToppingsNY() {
        Intent intent = new Intent(this, ToppingsActivityNY.class);
        if(toppingChoices != null){
            price -= (toppingChoices.length)*TOPPING_PRICE;
        }
        intent.putExtra("size", size);
        intent.putExtra("price", price);
        intent.putExtra("type", type);
        startActivity(intent);
    }

    public void createPizza(){
        NYPizza factory = new NYPizza();
        String crust = (String) crustText.getText();
        String style = type;
        Pizza pizza = null;
        ArrayList a = null;

        if(size == "Small" || size == "Medium" || size == "Large"){
            if(type == "BBQ Chicken"){
                pizza = factory.createBBQChicken();
                a = BBQChicken.getToppings2();
            }
            else if(type == "Deluxe"){
                pizza = factory.createDeluxe();
                a = Deluxe.getToppings2();
            }
            else if(type == "Meatzza"){
                pizza = factory.createMeatzza();
                a = Meatzza.getToppings2();
            }

            else if(type == "Build Your Own"){
                pizza = factory.createBuildYourOwn();
                pizza.add(convertToppingStorage(toppingChoices));
            }
            else{
                Toast.makeText(NewYorkActivity.this,
                        "Must Select Crust", Toast.LENGTH_SHORT).show();
            }
            pizza.add(a);
            pizza.setSize(convertToSize(size));
            Order currentOrder = StoreOrder.getCurOrder();
            currentOrder.add(pizza);
            selectedToppings2.clear();
            resetPrice();
        }
        else{
            Toast.makeText(NewYorkActivity.this,
                    "Must Select Size", Toast.LENGTH_SHORT).show();
        }

    }

    public void resetPrice(){
        price = 0;
    }

    public Size convertToSize(String sizeOption){
        Size finalSize = null;
        if(sizeOption == "Small"){
            finalSize = Size.small;
        }
        if(sizeOption == "Medium"){
            finalSize = Size.medium;
        }
        if(sizeOption == "Large"){
            finalSize = Size.large;
        }
        return finalSize;
    }

    private String getPrice() {

        if (type == "Meatzza") {
            if (size == "Small"){

                price = 15.99;
                priceText.setText(String.valueOf(price));


            }
            else if (size == "Large") {

                price = 19.99;
                priceText.setText(String.valueOf(price));


            } else if (size == "Medium") {

                price = 17.99;
                priceText.setText(String.valueOf(price));


            }

        }
        else if(type == "Deluxe"){
            price=0;
            if (size == "Small"){

                price = 14.99;
                priceText.setText(String.valueOf(price));


            } else if (size == "Large") {

                price = 18.99;
                priceText.setText(String.valueOf(price));


            } else if (size == "Medium") {

                price = 16.99;
                priceText.setText(String.valueOf(price));


            }
        }
        else if(type == "BBQ Chicken"){
            price=0;
            if (size == "Small"){

                price = 13.99;
                priceText.setText(String.valueOf(price));


            } else if (size == "Large") {

                price = 17.99;
                priceText.setText(String.valueOf(price));


            } else if (size == "Medium") {

                price = 15.99;
                priceText.setText(String.valueOf(price));


            }
        }
        else if(type =="Build Your Own"){
            price=0;

            if (size == "Small"){

                price=8.99;
                priceText.setText(String.valueOf(price));

            } else if (size == "Large") {

                price = 12.99;
                priceText.setText(String.valueOf(price));

            } else if (size == "Medium") {

                price = 10.99;
                priceText.setText(String.valueOf(price));

            }
        }
        return String.valueOf(price);
    }

    public ArrayList<String> convertToppingStorage(String[] toppings){
        ArrayList<String> finalTopping = new ArrayList<>();
        for(int i = 0; i < toppings.length; i++){
            finalTopping.add(toppings[i]);
        }
        return finalTopping;
    }

    public void openMain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}