package com.example.rupizza;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog.Builder;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import com.example.rupizza.Pizza;
import com.example.rupizza.StoreOrder;

import java.text.DecimalFormat;
import java.util.ArrayList;
public class CartActivity extends AppCompatActivity {

    TextView orderNumber;
    static TextView tvSubtotal;
    static TextView tvSalesTax;
    static TextView tvCartTotal;
    RecyclerView rvCartPizzas;
    Button btnClearCart, btnPlaceOrder;
    ArrayList<Pizza> pizzaList;

    private static final DecimalFormat df = new DecimalFormat("0.00");


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.orderviewact);

        tvSubtotal = findViewById(R.id.tvSubtotal);
        tvSalesTax = findViewById(R.id.tvSalesTax);
        tvCartTotal = findViewById(R.id.tvCartTotal);
        orderNumber = findViewById(R.id.tvOrderNum);
        rvCartPizzas = findViewById(R.id.rvPizzas);
        btnClearCart = findViewById(R.id.btnClearCart);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);

        pizzaList = new ArrayList<>();
        init();
        PizzaItemAdapter adapter = new PizzaItemAdapter(this, pizzaList); //create the adapter
        rvCartPizzas.setAdapter(adapter); //bind the list of items to the RecyclerView
        rvCartPizzas.setLayoutManager(new LinearLayoutManager(this));
        ActionBar actionBar = getSupportActionBar();

        // showing the back button in action bar
        actionBar.setDisplayHomeAsUpEnabled(true);


        // this event will enable the back

        btnClearCart.setOnClickListener(new View.OnClickListener() {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(CartActivity.this);

            @Override
            public void onClick(View v) {
                if (StoreOrder.getCurOrder().getPizzas().size() > 0) {
                    for (int i = 0; i <= StoreOrder.getCurOrder().getPizzas().size(); i++) {
                        StoreOrder.getCurOrder().getPizzas().remove(i);
                        adapter.notifyDataSetChanged();

                    }
                    pizzaList.clear();
                    adapter.notifyDataSetChanged();
                    updateCosts();
                }else{
                    alertDialog.setTitle("Cannot clear when no are in the pizza list!");
                    alertDialog.show();

                }
            }
        });

        btnPlaceOrder.setOnClickListener(new View.OnClickListener() {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(CartActivity.this);

            @Override
            public void onClick(View v) {
                if(StoreOrder.getCurOrder().getPizzas().size() < 1){

                    // Toast.makeText(CartActivity.this, "No Pizzas Added to Order", Toast.LENGTH_SHORT).show();
                    alertDialog.setTitle("No pizzas added to order");
                    alertDialog.setMessage("None");
                    alertDialog.setPositiveButton("OK",null);
                    alertDialog.show();

                    return;
                }
                StoreOrder.finish();
                alertDialog.setTitle("Success");
                alertDialog.setMessage("Order created");
                alertDialog.setPositiveButton("OK",null);

                alertDialog.show();

                Toast.makeText(CartActivity.this, "Order Placed", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
                init();
            }
        });

        updateCosts();
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Set the order number in the UI, load the list of pizzas in the
     * current order, and update the cost of the order in the UI
     */
    private void init(){
        orderNumber.setText("Order Number: " + StoreOrder.getOrderIDs());
        pizzaList.clear();
        pizzaList.addAll(StoreOrder.getCurOrder().getPizzas());
        updateCosts();
    }

    /**
     * Update the costs of the order in the UI
     */
    public static void updateCosts(){
        tvSubtotal.setText(df.format(StoreOrder.getCurOrder().getSubTotal()));
        tvSalesTax.setText(df.format(StoreOrder.getCurOrder().getTax()));
        tvCartTotal.setText(df.format(StoreOrder.getCurOrder().getTotal()));
    }
}