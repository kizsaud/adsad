package com.example.rupizza;

public interface ToppingsRecyclerInterface {
    void onItemCLick(int Position);
}
